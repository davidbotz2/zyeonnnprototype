"use client";

import { FormEvent, useRef, useState } from "react";

type Comment = { id: string; name: string; message: string; avatarUrl: string; createdAt: string };
const projects = [
  { title: "Nutrify", type: "Web App", desc: "Pelacak nutrisi, makanan, air, dan kebiasaan sehat.", tags: ["Next.js", "AI", "Database"] },
  { title: "ZyeonnN Community Bot", type: "Discord Bot", desc: "Bot komunitas dengan slash commands dan fitur moderasi.", tags: ["Node.js", "Discord.js"] },
  { title: "ClassHub", type: "Web App", desc: "Dashboard kelas untuk jadwal, tugas, dan pengumuman.", tags: ["HTML", "JavaScript"] }
];
const tech = ["HTML5", "CSS3", "JavaScript", "TypeScript", "React", "Next.js", "Node.js", "Git", "Vercel", "PostgreSQL", "Python", "Discord.js"];

function SpiderPortrait() {
  const box = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  function move(e: React.PointerEvent<HTMLDivElement>) {
    const el = box.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = (e.clientY - r.top) / r.height;
    el.style.setProperty("--rx", `${(0.5-y)*22}deg`);
    el.style.setProperty("--ry", `${(x-0.5)*28}deg`);
    el.style.setProperty("--px", `${(x-0.5)*18}px`);
    el.style.setProperty("--py", `${(y-0.5)*18}px`);
    setActive(true);
  }
  function reset() {
    const el = box.current; if (el) {
      el.style.setProperty("--rx", "0deg"); el.style.setProperty("--ry", "0deg");
      el.style.setProperty("--px", "0px"); el.style.setProperty("--py", "0px");
    }
    setActive(false);
  }
  return <div className={`portrait-scene ${active ? "is-active" : ""}`} ref={box} onPointerMove={move} onPointerLeave={reset} onPointerDown={() => setActive(true)} aria-label="Foto interaktif, gerakkan pointer">
    <div className="portrait-card">
      <div className="portrait-label">ABOUT THE CREATOR <span>ZY-001</span></div>
      <div className="portrait-art">
        <img className="profile-img" src="/images/profile.png" alt="Foto profil ZYEONNN" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
        <div className="profile-fallback"><span>Z.</span><small>ADD YOUR PHOTO</small></div>
        <div className="spider-hero" aria-hidden="true">
          <img src="/images/spiderman.png" alt="" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
          <div className="hero-fallback"><div className="hero-head"><i /><b /></div><div className="hero-body"><span className="web-mark">✳</span></div><div className="hero-arm left" /><div className="hero-arm right" /></div>
        </div>
        <div className="scan-line" />
      </div>
      <div className="portrait-caption"><b>ZYEONNN</b><span>CREATOR · GAMER · DEVELOPER</span></div>
      <div className="portrait-bottom"><span>INTERACTIVE PROFILE</span><span>EST. 2024</span></div>
    </div>
    <div className="pointer-hint">{active ? "TRACKING POINTER" : "GERAKKAN POINTER KE FOTO"}</div>
  </div>;
}

export default function Portfolio({ initialComments }: { initialComments: Comment[] }) {
  const [tab, setTab] = useState("Projects");
  const [comments, setComments] = useState(initialComments);
  const [commentStatus, setCommentStatus] = useState("");
  const [contactStatus, setContactStatus] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [musicOn, setMusicOn] = useState(false);
  const audio = useRef<HTMLAudioElement>(null);

  async function submitComment(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setCommentStatus("Mengirim...");
    const form = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/comments", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ name: form.get("name"), message: form.get("message"), website: form.get("website") }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal mengirim komentar.");
      setComments((old) => [data, ...old]); e.currentTarget.reset(); setCommentStatus("Komentar berhasil dikirim.");
    } catch (err) { setCommentStatus(err instanceof Error ? err.message : "Gagal mengirim."); }
  }
  async function submitContact(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setContactStatus("Mengirim...");
    const form = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ name: form.get("name"), email: form.get("email"), message: form.get("message"), website: form.get("website") }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "Gagal menyimpan pesan.");
      e.currentTarget.reset(); setContactStatus(data.message || "Pesan tersimpan.");
    } catch (err) { setContactStatus(err instanceof Error ? err.message : "Gagal mengirim."); }
  }
  async function toggleMusic() {
    if (!audio.current) return;
    if (musicOn) { audio.current.pause(); setMusicOn(false); }
    else { try { await audio.current.play(); setMusicOn(true); } catch { setMusicOn(false); } }
  }

  return <main>
    <audio ref={audio} src="/music/background.mp3" loop preload="none" onPause={() => setMusicOn(false)} onPlay={() => setMusicOn(true)} />
    <header className="nav-shell">
      <a className="brand" href="#home">ZYEONN<span>N.</span></a>
      <div className={`nav-links ${menuOpen ? "open" : ""}`}>
        <a onClick={() => setMenuOpen(false)} href="#home">Home</a><a onClick={() => setMenuOpen(false)} href="#about">About</a><a onClick={() => setMenuOpen(false)} href="#portfolio">Portfolio</a><a onClick={() => setMenuOpen(false)} href="#contact">Contact</a>
      </div>
      <div className="nav-actions"><button className="icon-button" onClick={toggleMusic} aria-label="Putar atau jeda musik">{musicOn ? "Ⅱ" : "♫"}</button><button className="icon-button menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Buka menu">☰</button></div>
    </header>

    <section className="hero section" id="home">
      <div className="hero-copy"><p className="eyebrow"><span className="live-dot" /> DIGITAL CREATOR & TECH ENTHUSIAST</p>
        <h1>Welcome to<br/><span>My Portfolio</span></h1><h2>Building digital things with imagination.</h2>
        <p className="lead">Halo, aku ZyeonnN. Tempat untuk mengenal diriku, melihat proyek yang kubuat, dan menemukan semua media sosialku dalam satu halaman.</p>
        <div className="hero-buttons"><a className="primary-button" href="#portfolio">Lihat Projek ↗</a><a className="secondary-button" href="#contact">Hubungi Saya</a></div>
        <div className="social-row"><span>FIND ME</span><a href="https://github.com/" target="_blank">GitHub ↗</a><a href="https://instagram.com/davidreihansptra" target="_blank">Instagram ↗</a><a href="https://tiktok.com/@2zyeonnn" target="_blank">TikTok ↗</a></div>
      </div>
      <div className="id-stage"><div className="lanyard"><div className="lanyard-clip" /></div><div className="id-card" tabIndex={0} onClick={(e) => e.currentTarget.classList.toggle("flipped")} onKeyDown={(e) => {if(e.key==="Enter"||e.key===" ") e.currentTarget.classList.toggle("flipped")}}><div className="id-inner"><div className="id-front"><div className="id-top"><span>PERSONAL ID</span><span>ZY-001</span></div><div className="id-photo"><span>Z.</span></div><h3>ZYEONNN</h3><p>CREATOR · GAMER · DEVELOPER</p><div className="id-foot"><span>PORTFOLIO</span><span>EST. 2024</span></div></div><div className="id-back"><span className="qr">▦ ▦ ▦<br/>▦ ▢ ▦<br/>▦ ▦ ▦</span><h3>ZYEONNN</h3><p>Digital creator</p><small>Tap to flip back</small></div></div></div><span className="float-hint">TAP ID TO FLIP</span></div>
    </section>

    <section className="section about-section" id="about"><div className="section-heading"><span>01 / ABOUT</span><h2>About <em>Me</em></h2><p>Kenali orang di balik layar.</p></div>
      <div className="about-grid"><SpiderPortrait/><div className="about-copy"><p className="eyebrow">HELLO, WORLD!</p><h3>Hi, I'm <span>ZYEONNN</span></h3><p>Aku seorang digital creator yang tertarik pada pengembangan web, teknologi, gaming, dan desain interaktif. Aku suka mengubah ide menjadi proyek yang bisa digunakan.</p><p>Bagian foto ini punya efek pointer: arahkan mouse atau sentuh area foto untuk memiringkan karakter. Tambahkan gambar profil dan aset superhero milikmu agar efek visual tampil penuh.</p><a className="primary-button" href="#contact">Hubungi Saya ↗</a><div className="edu-grid"><div><small>EDUCATION</small><b>Learning by building</b><span>Technology · Design · Code</span></div><div><small>EXPERIENCE</small><b>Personal Projects</b><span>Web · Community · Tools</span></div></div></div></div>
      <div className="stats-grid"><div><b>03</b><span>Projects</span></div><div><b>03</b><span>Certificates</span></div><div><b>01</b><span>Goals in progress</span></div></div>
    </section>

    <section className="section music-section"><div><span className="eyebrow">SOUNDTRACK</span><h2>A little music.<br/><em>A lot of ideas.</em></h2><p>Musik untuk menemani proses berkarya.</p><button className="secondary-button" onClick={toggleMusic}>{musicOn ? "Jeda musik" : "Putar musik lokal"} ♫</button><small className="muted">Taruh file musik milikmu di public/music/background.mp3</small></div><div className="music-card"><div className="album-art">♫</div><div className="music-meta"><b>ZYEONNN — Daily Rotation</b><span>Local audio player</span><div className="progress"><i /></div><div className="player-row"><span>♪</span><button onClick={toggleMusic}>{musicOn ? "Ⅱ" : "▶"}</button><span>∞</span></div></div></div></section>

    <section className="section" id="portfolio"><div className="section-heading"><span>02 / SELECTED WORK</span><h2>My <em>Portfolio</em></h2><p>Beberapa hal yang sedang dan pernah kubangun.</p></div>
      <div className="tabs">{["Projects","Certificates","Achievements","Tech Stack"].map(t => <button key={t} className={tab===t?"active":""} onClick={() => setTab(t)}>{t}</button>)}</div>
      {tab==="Projects" && <div className="project-grid">{projects.map((p,i)=><article className="project-card" key={p.title}><div className={`project-preview preview-${i+1}`}><span>PROJECT / 0{i+1}</span><b>{p.title}</b><small>{p.type}</small></div><div className="project-info"><h3>{p.title}</h3><p>{p.desc}</p><div className="tags">{p.tags.map(t=><span key={t}>{t}</span>)}</div><button className="text-button" onClick={() => alert(`${p.title}\n\n${p.desc}\n\nTeknologi: ${p.tags.join(", ")}`)}>Lihat detail ↗</button></div></article>)}</div>}
      {tab==="Certificates" && <div className="empty-grid"><div className="certificate">CERTIFICATE<br/><b>Learning & Building</b><small>ZYEONNN · 2026</small></div><div className="certificate">CERTIFICATE<br/><b>Web Development</b><small>Tambahkan sertifikat asli</small></div><div className="certificate">CERTIFICATE<br/><b>Technology Skills</b><small>Tambahkan sertifikat asli</small></div></div>}
      {tab==="Achievements" && <div className="achievement-panel"><span>✦</span><h3>Every project is progress.</h3><p>Bagian ini bisa diisi pencapaian, penghargaan, atau milestone yang benar-benar kamu miliki.</p></div>}
      {tab==="Tech Stack" && <div className="tech-grid">{tech.map((t,i)=><div key={t}><span>{["⌘","◈","JS","TS","⚛","N","⬡","⑂","▲","▤","Py","◉"][i]}</span><b>{t}</b></div>)}</div>}
    </section>

    <section className="section contact-section" id="contact"><div className="section-heading"><span>03 / GET IN TOUCH</span><h2>Hubungi <em>Saya</em></h2><p>Punya ide atau ingin ngobrol tentang proyek? Kirim pesan.</p></div><div className="contact-grid">
      <form className="glass-form" onSubmit={submitContact}><h3>Kirim Pesan</h3><label>Nama<input name="name" minLength={2} maxLength={80} required placeholder="Nama kamu"/></label><label>Email<input type="email" name="email" required placeholder="email@contoh.com"/></label><label>Pesan<textarea name="message" minLength={5} maxLength={2000} required placeholder="Tulis pesanmu..." rows={4}/></label><input className="honeypot" name="website" tabIndex={-1} autoComplete="off"/><button className="primary-button" type="submit">Kirim Pesan ↗</button><p className="form-status">{contactStatus}</p></form>
      <div className="comment-panel"><h3>Komentar <span>({comments.length})</span></h3><form onSubmit={submitComment}><label>Nama<input name="name" minLength={2} maxLength={60} required placeholder="Nama kamu"/></label><label>Komentar<textarea name="message" minLength={2} maxLength={600} required rows={3} placeholder="Tulis komentar..."/></label><input className="honeypot" name="website" tabIndex={-1} autoComplete="off"/><button className="secondary-button" type="submit">Kirim Komentar</button><p className="form-status">{commentStatus}</p></form><div className="comment-list">{comments.map(c=><article className="comment" key={c.id}><div className="avatar">{c.name.slice(0,1).toUpperCase()}</div><div><b>{c.name}</b><small>{new Date(c.createdAt).toLocaleString("id-ID")}</small><p>{c.message}</p></div></article>)}</div></div>
    </div></section>
    <footer><a className="brand" href="#home">ZYEONN<span>N.</span></a><p>Digital creator · Gamer · Developer</p><div><a href="#home">Beranda</a><a href="#about">Tentang Saya</a><a href="#portfolio">Portofolio</a><a href="#contact">Kontak</a></div><small>© 2026 ZYEONNN. Built with care.</small><a className="back-top" href="#home" aria-label="Kembali ke atas">↑</a></footer>
  </main>;
}