ZYEONNN FULLSTACK PORTFOLIO
===========================

FITUR YANG SUDAH DIBUAT
- Website portofolio responsif bergaya navy/blue glass.
- Kartu ID dengan tali, animasi mengambang, tilt mengikuti mouse/jari, klik untuk membalik.
- Efek hover foto About Me: pointer mengendalikan kemiringan karakter; overlay superhero berubah dari foto profil ke gambar Spider-Man yang kamu tambahkan.
- Tab Projects / Certificates / Achievements / Tech Stack.
- Halaman detail proyek modal sederhana.
- Musik melalui file lokal.
- Form komentar dan kontak memakai API server.
- Komentar disimpan di PostgreSQL (Neon) setelah DATABASE_URL disetel.
- Validasi input dasar, batas panjang input, honeypot sederhana untuk spam.

PENTING TENTANG EFEK SPIDER-MAN
Efeknya sudah dibuat di kode: saat pointer masuk ke foto About Me, lapisan karakter superhero muncul dan mengikuti arah pointer dengan transformasi 3D. Untuk menampilkan gambar Spider-Man yang benar-benar sesuai, taruh aset yang kamu punya/berhak gunakan di:
  public/images/spiderman.png
dan foto profil di:
  public/images/profile.png
Tanpa file tersebut, situs memakai ilustrasi fallback CSS. Pose tidak menggunakan AI live pose-tracking; gerak yang tersedia adalah tilt/parallax berdasarkan pointer. Untuk pose Spider-Man yang benar-benar berganti sesuai arah, perlu beberapa sprite/frame pose (bisa ditambahkan nanti).

CARA MENJALANKAN DI KOMPUTER
1. Instal Node.js versi 20 atau lebih baru.
2. Ekstrak ZIP dan buka folder proyek.
3. Salin .env.example menjadi .env.local.
4. Buat database PostgreSQL gratis di Neon (neon.tech), lalu masukkan connection string ke DATABASE_URL.
5. Buka SQL Editor database Neon, jalankan isi file database/schema.sql.
6. Di terminal pada folder proyek:
   npm install
   npm run dev
7. Buka http://localhost:3000

DEPLOY KE VERCEL
1. Upload folder proyek ke GitHub, lalu import repository ke Vercel.
2. Tambahkan DATABASE_URL di Project Settings > Environment Variables.
3. Pastikan schema database sudah dijalankan di Neon.
4. Deploy ulang.

TANPA DATABASE_URL
Website tetap dapat dibuka, tetapi endpoint komentar/kontak akan mengembalikan pesan konfigurasi database belum tersedia. Ini disengaja agar data tidak hilang diam-diam atau disimpan ke file sementara Vercel.

CATATAN
- Tidak ada API key berbayar yang disertakan.
- Form kontak saat ini menyimpan pesan ke database; pengiriman email otomatis belum dikonfigurasi.
- Aset foto dan musik perlu kamu masukkan sendiri.
