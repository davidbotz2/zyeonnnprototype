import { NextResponse } from "next/server";
import { neon } from "@neondatabase/serverless";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "DATABASE_URL belum disetel." }, { status: 503 });
  try {
    const sql = neon(process.env.DATABASE_URL);
    const rows = await sql`SELECT id, name, message, avatar_url, created_at FROM comments ORDER BY created_at DESC LIMIT 30`;
    return NextResponse.json(rows.map((r: any) => ({
      id: String(r.id), name: r.name, message: r.message,
      avatarUrl: r.avatar_url || "", createdAt: new Date(r.created_at).toISOString()
    })));
  } catch {
    return NextResponse.json({ error: "Gagal mengambil komentar." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Database belum dikonfigurasi. Isi DATABASE_URL terlebih dahulu." }, { status: 503 });
  try {
    const body = await req.json();
    if (body.website) return NextResponse.json({ ok: true }); // honeypot
    const name = String(body.name || "").trim().slice(0, 60);
    const message = String(body.message || "").trim().slice(0, 600);
    const avatarUrl = ""; // Only same-origin/local assets accepted for now.
    if (name.length < 2 || message.length < 2) return NextResponse.json({ error: "Nama dan komentar minimal 2 karakter." }, { status: 400 });
    const sql = neon(process.env.DATABASE_URL);
    const rows = await sql`INSERT INTO comments (name, message, avatar_url) VALUES (${name}, ${message}, ${avatarUrl}) RETURNING id, name, message, avatar_url, created_at`;
    const r: any = rows[0];
    return NextResponse.json({ id: String(r.id), name: r.name, message: r.message, avatarUrl: r.avatar_url || "", createdAt: new Date(r.created_at).toISOString() }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Komentar gagal disimpan. Coba lagi." }, { status: 500 });
  }
}