import { NextResponse } from "next/server";
import { neon } from "@neondatabase/serverless";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Database belum dikonfigurasi. Isi DATABASE_URL terlebih dahulu." }, { status: 503 });
  try {
    const body = await req.json();
    if (body.website) return NextResponse.json({ ok: true });
    const name = String(body.name || "").trim().slice(0, 80);
    const email = String(body.email || "").trim().slice(0, 254);
    const message = String(body.message || "").trim().slice(0, 2000);
    if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
      return NextResponse.json({ error: "Periksa nama, email, dan pesan." }, { status: 400 });
    }
    const sql = neon(process.env.DATABASE_URL);
    await sql`INSERT INTO contact_messages (name, email, message) VALUES (${name}, ${email}, ${message})`;
    return NextResponse.json({ ok: true, message: "Pesan tersimpan. Email otomatis belum diaktifkan." }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Pesan gagal disimpan. Coba lagi." }, { status: 500 });
  }
}