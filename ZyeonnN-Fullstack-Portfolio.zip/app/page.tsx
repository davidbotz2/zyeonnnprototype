import Portfolio from "@/components/Portfolio";
import { neon } from "@neondatabase/serverless";

export const dynamic = "force-dynamic";

async function getInitialComments() {
  if (!process.env.DATABASE_URL) return [];
  try {
    const sql = neon(process.env.DATABASE_URL);
    const rows = await sql`SELECT id, name, message, avatar_url, created_at FROM comments ORDER BY created_at DESC LIMIT 20`;
    return rows.map((r: any) => ({
      id: String(r.id), name: r.name, message: r.message,
      avatarUrl: r.avatar_url || "", createdAt: new Date(r.created_at).toISOString()
    }));
  } catch {
    return [];
  }
}

export default async function Home() {
  const comments = await getInitialComments();
  return <Portfolio initialComments={comments} />;
}